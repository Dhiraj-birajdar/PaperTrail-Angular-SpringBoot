package com.papertrail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaperTrailSpringBootRestApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
