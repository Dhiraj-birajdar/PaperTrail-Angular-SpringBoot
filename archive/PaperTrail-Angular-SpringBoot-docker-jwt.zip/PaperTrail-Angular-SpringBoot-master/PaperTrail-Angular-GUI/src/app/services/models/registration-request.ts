/* tslint:disable */
/* eslint-disable */
export interface RegistrationRequest {
  email: string;
  firstname: string;
  lastname: string;
  password: string;
}
