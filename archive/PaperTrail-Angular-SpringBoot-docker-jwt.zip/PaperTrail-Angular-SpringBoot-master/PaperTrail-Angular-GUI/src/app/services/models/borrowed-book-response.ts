/* tslint:disable */
/* eslint-disable */
export interface BorrowedBookResponse {
  author?: string;
  id?: number;
  isbn?: string;
  rate?: number;
  returnApproved?: boolean;
  returned?: boolean;
  title?: string;
}
