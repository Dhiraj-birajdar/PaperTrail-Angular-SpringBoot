/* tslint:disable */
/* eslint-disable */
export interface BookResponse {
  archived?: boolean;
  author?: string;
  cover?: Array<string>;
  id?: number;
  isbn?: string;
  owner?: string;
  rate?: number;
  shareable?: boolean;
  synopsis?: string;
  title?: string;
}
